// ─── DHAN POINT ADDON v2 — FLOATING PANEL CONTENT SCRIPT ────────────────────
(function () {
  'use strict';

  const PANEL_ID = 'dhan-addon-panel-root';
  const POINT_OPTIONS = [10, 20, 30, 40, 50, 60, 75, 100, 150, 200];

  let state = {
    targetPts: 50,
    slPts: 50,
    direction: 'BUY',
    autoUpdate: true,
    active: false,
    price: null,
    prevPrice: null,
  };

  let intervalId = null;
  let panelVisible = false;

  // ─── TOOLBAR ICON CLICK → TOGGLE PANEL ──────────────────────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'TOGGLE_PANEL') {
      panelVisible ? hidePanel() : showPanel();
    }
  });

  // ─── SHOW / HIDE ─────────────────────────────────────────────────────────
  function showPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) {
      existing.style.display = 'block';
      panelVisible = true;
      return;
    }
    chrome.storage.local.get(
      ['targetPts','slPts','direction','autoUpdate','panelX','panelY'],
      (data) => {
        if (data.targetPts)  state.targetPts  = data.targetPts;
        if (data.slPts)      state.slPts      = data.slPts;
        if (data.direction)  state.direction  = data.direction;
        if (data.autoUpdate !== undefined) state.autoUpdate = data.autoUpdate;
        const x = data.panelX ?? (window.innerWidth - 320 - 24);
        const y = data.panelY ?? 80;
        injectCSS();
        buildPanel(x, y);
        panelVisible = true;
        startPricePoll();
      }
    );
  }

  function hidePanel() {
    const el = document.getElementById(PANEL_ID);
    if (el) el.style.display = 'none';
    panelVisible = false;
  }

  // ─── STYLES ──────────────────────────────────────────────────────────────
  function injectCSS() {
    if (document.getElementById('dhan-addon-css')) return;
    const s = document.createElement('style');
    s.id = 'dhan-addon-css';
    s.textContent = `
      @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Syne:wght@600;700;800&display=swap');

      #dhan-addon-panel-root {
        position: fixed;
        z-index: 2147483647;
        width: 296px;
        font-family: 'Syne', 'Segoe UI', sans-serif;
        filter: drop-shadow(0 20px 60px rgba(0,0,0,.8));
      }
      .dap {
        background: #0d1117;
        border: 1px solid #1e2535;
        border-radius: 14px;
        overflow: hidden;
        position: relative;
      }
      /* titlebar */
      .dap-bar {
        display: flex; align-items: center; gap: 8px;
        padding: 9px 12px;
        background: #111520;
        border-bottom: 1px solid #1e2535;
        cursor: grab;
      }
      .dap-bar:active { cursor: grabbing; }
      .dap-logo {
        width: 22px; height: 22px; border-radius: 6px; flex-shrink:0;
        background: linear-gradient(135deg,#4f8cff,#7c5cbf);
        display:flex;align-items:center;justify-content:center;
        font-size:11px;font-weight:800;color:#fff;
      }
      .dap-title { font-size:12px;font-weight:800;color:#e8ecf4;letter-spacing:-.2px; }
      .dap-status {
        margin-left:auto; display:flex; align-items:center; gap:4px;
        font-size:9px;font-weight:700;font-family:'JetBrains Mono',monospace;
        padding:2px 7px; border-radius:20px;
        background:#181d2a; border:1px solid #1e2535; color:#6b7a99;
        transition:all .3s;
      }
      .dap-status.live { background:rgba(0,230,118,.08); border-color:rgba(0,230,118,.3); color:#00e676; }
      .dap-dot { width:5px;height:5px;border-radius:50%;background:currentColor; }
      .dap-status.live .dap-dot { animation:dap-pulse 1.4s infinite; box-shadow:0 0 4px currentColor; }
      @keyframes dap-pulse{0%,100%{opacity:1}50%{opacity:.2}}
      .dap-x {
        width:18px;height:18px;border-radius:50%;
        background:rgba(255,68,68,.15); border:1px solid rgba(255,68,68,.3);
        color:#ff4444; display:flex;align-items:center;justify-content:center;
        cursor:pointer;font-size:10px;margin-left:5px;transition:background .15s;
      }
      .dap-x:hover{background:rgba(255,68,68,.3);}
      /* price */
      .dap-price {
        padding:10px 13px 8px; background:#111520; border-bottom:1px solid #1e2535;
      }
      .dap-lbl { font-size:8px;text-transform:uppercase;letter-spacing:1.5px;color:#6b7a99;font-weight:600;margin-bottom:3px;font-family:'JetBrains Mono',monospace; }
      .dap-price-row{display:flex;align-items:baseline;gap:3px;}
      .dap-psym{font-size:11px;color:#6b7a99;}
      .dap-pval{font-size:26px;font-weight:800;font-family:'JetBrains Mono',monospace;color:#e8ecf4;letter-spacing:-1.5px;transition:color .25s;}
      .dap-pval.up{color:#00e676;} .dap-pval.down{color:#ff4444;}
      .dap-ptime{font-size:9px;color:#6b7a99;margin-top:1px;font-family:'JetBrains Mono',monospace;}
      /* direction */
      .dap-dir { padding:9px 13px; border-bottom:1px solid #1e2535; }
      .dap-dir-grid{display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:5px;}
      .dap-dbtn {
        padding:8px;border-radius:8px;border:1.5px solid #1e2535;
        background:#181d2a;font-size:12px;font-weight:800;cursor:pointer;
        text-align:center;color:#6b7a99;transition:all .15s;letter-spacing:.5px;
        font-family:'Syne','Segoe UI',sans-serif;
      }
      .dap-dbtn:hover{color:#e8ecf4;}
      .dap-dbtn.ba{background:rgba(0,230,118,.1);border-color:#00e676;color:#00e676;box-shadow:0 0 10px rgba(0,230,118,.15);}
      .dap-dbtn.sa{background:rgba(255,68,68,.1);border-color:#ff4444;color:#ff4444;box-shadow:0 0 10px rgba(255,68,68,.15);}
      /* tsl */
      .dap-tsl{display:grid;grid-template-columns:1fr 1fr;gap:6px;padding:9px 13px;border-bottom:1px solid #1e2535;}
      .dap-tbox{padding:8px 9px;border-radius:8px;text-align:center;}
      .dap-tbox.t{background:rgba(0,230,118,.07);border:1px solid rgba(0,230,118,.2);}
      .dap-tbox.s{background:rgba(255,68,68,.07);border:1px solid rgba(255,68,68,.2);}
      .dap-tlbl{font-size:7px;text-transform:uppercase;letter-spacing:1.5px;font-weight:700;margin-bottom:2px;font-family:'JetBrains Mono',monospace;}
      .dap-tbox.t .dap-tlbl{color:#00e676;} .dap-tbox.s .dap-tlbl{color:#ff4444;}
      .dap-tval{font-size:14px;font-weight:800;font-family:'JetBrains Mono',monospace;letter-spacing:-.5px;}
      .dap-tbox.t .dap-tval{color:#00e676;} .dap-tbox.s .dap-tval{color:#ff4444;}
      .dap-tsub{font-size:8px;color:#6b7a99;margin-top:1px;font-family:'JetBrains Mono',monospace;}
      /* pts */
      .dap-pts{padding:9px 13px;border-bottom:1px solid #1e2535;}
      .dap-plbl{font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;margin-bottom:4px;font-family:'JetBrains Mono',monospace;}
      .dap-plbl.t{color:#00e676;} .dap-plbl.s{color:#ff4444;margin-top:9px;}
      .dap-pgrid{display:grid;grid-template-columns:repeat(5,1fr);gap:4px;margin-bottom:5px;}
      .dap-pb{
        padding:5px 2px;border-radius:6px;border:1px solid #1e2535;background:#181d2a;
        font-size:10px;font-weight:700;font-family:'JetBrains Mono',monospace;
        cursor:pointer;color:#6b7a99;text-align:center;transition:all .12s;
      }
      .dap-pb:hover{color:#e8ecf4;border-color:rgba(79,140,255,.3);}
      .dap-pb.at{background:rgba(0,230,118,.1);border-color:#00e676;color:#00e676;}
      .dap-pb.as{background:rgba(255,68,68,.1);border-color:#ff4444;color:#ff4444;}
      .dap-crow{display:flex;align-items:center;gap:5px;}
      .dap-clbl{font-size:9px;color:#6b7a99;font-family:'JetBrains Mono',monospace;flex-shrink:0;}
      .dap-cin{
        width:60px;background:#181d2a;border:1px solid #1e2535;border-radius:6px;
        padding:4px 7px;font-size:11px;font-weight:700;font-family:'JetBrains Mono',monospace;
        color:#e8ecf4;outline:none;text-align:center;
      }
      .dap-cin:focus{border-color:#4f8cff;}
      /* auto row */
      .dap-arow{display:flex;align-items:center;justify-content:space-between;padding:7px 13px;border-bottom:1px solid #1e2535;}
      .dap-albl{font-size:10px;color:#6b7a99;font-weight:600;}
      .dap-tog{width:34px;height:18px;background:#1e2535;border-radius:9px;position:relative;cursor:pointer;transition:background .2s;flex-shrink:0;}
      .dap-tog.on{background:#4f8cff;}
      .dap-tog::after{content:'';position:absolute;width:12px;height:12px;background:#fff;border-radius:50%;top:3px;left:3px;transition:transform .2s;}
      .dap-tog.on::after{transform:translateX(16px);}
      /* action btn */
      .dap-act{padding:10px 13px 12px;}
      .dap-btn{
        width:100%;padding:11px;border:none;border-radius:9px;
        font-size:13px;font-weight:800;font-family:'Syne','Segoe UI',sans-serif;
        cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;
        transition:all .15s;letter-spacing:.3px;
      }
      .dap-btn.go{background:linear-gradient(135deg,#4f8cff,#6a5acd);color:#fff;}
      .dap-btn.go:hover{box-shadow:0 4px 16px rgba(79,140,255,.5);transform:translateY(-1px);}
      .dap-btn.stop{background:linear-gradient(135deg,#ff4444,#c0392b);color:#fff;}
      .dap-btn.stop:hover{box-shadow:0 4px 16px rgba(255,68,68,.4);transform:translateY(-1px);}
      .dap-btn:active{transform:translateY(0)!important;}
    `;
    document.head.appendChild(s);
  }

  // ─── BUILD PANEL ─────────────────────────────────────────────────────────
  function buildPanel(x, y) {
    const root = document.createElement('div');
    root.id = PANEL_ID;
    root.style.cssText = `left:${x}px;top:${y}px;`;

    root.innerHTML = `
      <div class="dap">
        <div class="dap-bar" id="dap-handle">
          <div class="dap-logo">D</div>
          <span class="dap-title">Dhan Addon</span>
          <div class="dap-status" id="dap-status">
            <span class="dap-dot"></span>
            <span id="dap-stxt">idle</span>
          </div>
          <div class="dap-x" id="dap-close">✕</div>
        </div>

        <div class="dap-price">
          <div class="dap-lbl">Live Price</div>
          <div class="dap-price-row">
            <span class="dap-psym">₹</span>
            <span class="dap-pval" id="dap-pval">—</span>
          </div>
          <div class="dap-ptime" id="dap-ptime">waiting for price...</div>
        </div>

        <div class="dap-dir">
          <div class="dap-lbl">Order Direction</div>
          <div class="dap-dir-grid">
            <button class="dap-dbtn ba" id="dap-buy">▲ BUY</button>
            <button class="dap-dbtn"    id="dap-sell">▼ SELL</button>
          </div>
        </div>

        <div class="dap-tsl">
          <div class="dap-tbox t">
            <div class="dap-tlbl" id="dap-tlbl">▲ Target</div>
            <div class="dap-tval" id="dap-tval">—</div>
            <div class="dap-tsub" id="dap-tsub">+50 pts</div>
          </div>
          <div class="dap-tbox s">
            <div class="dap-tlbl" id="dap-slbl">▼ Stop Loss</div>
            <div class="dap-tval" id="dap-sval">—</div>
            <div class="dap-tsub" id="dap-ssub">-50 pts</div>
          </div>
        </div>

        <div class="dap-pts">
          <div class="dap-plbl t">Target Points</div>
          <div class="dap-pgrid" id="dap-tgrid"></div>
          <div class="dap-crow">
            <span class="dap-clbl">Custom:</span>
            <input class="dap-cin" id="dap-tcust" type="number" min="1" placeholder="pts"/>
            <span class="dap-clbl" style="color:#00e676">▲pts</span>
          </div>

          <div class="dap-plbl s">SL Points</div>
          <div class="dap-pgrid" id="dap-sgrid"></div>
          <div class="dap-crow">
            <span class="dap-clbl">Custom:</span>
            <input class="dap-cin" id="dap-scust" type="number" min="1" placeholder="pts"/>
            <span class="dap-clbl" style="color:#ff4444">▼pts</span>
          </div>
        </div>

        <div class="dap-arow">
          <span class="dap-albl">Auto-update on price change</span>
          <div class="dap-tog on" id="dap-autotog"></div>
        </div>

        <div class="dap-act">
          <button class="dap-btn go" id="dap-actbtn">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><polygon points="5,3 19,12 5,21"/></svg>
            Start Tracking
          </button>
        </div>
      </div>`;

    document.body.appendChild(root);
    buildGrids();
    refreshAll();
    wireEvents(root);
    makeDraggable(root, document.getElementById('dap-handle'));
  }

  // ─── GRIDS ────────────────────────────────────────────────────────────────
  function buildGrids() {
    ['dap-tgrid','dap-sgrid'].forEach((id, i) => {
      const g = document.getElementById(id);
      if (!g) return;
      g.innerHTML = '';
      POINT_OPTIONS.forEach(pts => {
        const b = document.createElement('button');
        b.className = 'dap-pb';
        b.textContent = pts;
        b.dataset.pts = pts;
        b.addEventListener('click', () => {
          if (i === 0) { state.targetPts = pts; document.getElementById('dap-tcust').value = ''; }
          else         { state.slPts     = pts; document.getElementById('dap-scust').value = ''; }
          refreshAll();
          saveState();
          if (state.active && state.price) fillFields(state.price);
        });
        g.appendChild(b);
      });
    });
  }

  function refreshGridHighlights() {
    document.querySelectorAll('#dap-tgrid .dap-pb').forEach(b =>
      b.classList.toggle('at', parseInt(b.dataset.pts) === state.targetPts));
    document.querySelectorAll('#dap-sgrid .dap-pb').forEach(b =>
      b.classList.toggle('as', parseInt(b.dataset.pts) === state.slPts));
  }

  // ─── REFRESH ALL UI ───────────────────────────────────────────────────────
  function refreshAll() {
    refreshGridHighlights();
    refreshDirection();
    refreshTSL();
    refreshStatus();
    refreshAutoToggle();
  }

  function refreshDirection() {
    const bb = document.getElementById('dap-buy');
    const sb = document.getElementById('dap-sell');
    if (!bb || !sb) return;
    bb.className = 'dap-dbtn' + (state.direction === 'BUY'  ? ' ba' : '');
    sb.className = 'dap-dbtn' + (state.direction === 'SELL' ? ' sa' : '');
  }

  function refreshTSL() {
    const p   = state.price;
    const dir = state.direction;
    const isBuy = dir === 'BUY';

    const tlbl = document.getElementById('dap-tlbl');
    const slbl = document.getElementById('dap-slbl');
    const tval = document.getElementById('dap-tval');
    const sval = document.getElementById('dap-sval');
    const tsub = document.getElementById('dap-tsub');
    const ssub = document.getElementById('dap-ssub');
    if (!tlbl) return;

    tlbl.textContent = isBuy ? '▲ Target'    : '▼ Target';
    slbl.textContent = isBuy ? '▼ Stop Loss' : '▲ Stop Loss';
    tsub.textContent = isBuy ? `+${state.targetPts} pts` : `-${state.targetPts} pts`;
    ssub.textContent = isBuy ? `-${state.slPts} pts`     : `+${state.slPts} pts`;

    if (p) {
      const tv = isBuy ? (p + state.targetPts).toFixed(2)              : Math.max(.05, p - state.targetPts).toFixed(2);
      const sv = isBuy ? Math.max(.05, p - state.slPts).toFixed(2)     : (p + state.slPts).toFixed(2);
      tval.textContent = '₹' + tv;
      sval.textContent = '₹' + sv;
    } else {
      tval.textContent = '—';
      sval.textContent = '—';
    }
  }

  function refreshStatus() {
    const statusEl = document.getElementById('dap-status');
    const stxtEl   = document.getElementById('dap-stxt');
    const btnEl    = document.getElementById('dap-actbtn');
    if (!statusEl) return;
    if (state.active) {
      statusEl.className = 'dap-status live';
      if (stxtEl) stxtEl.textContent = 'live';
      if (btnEl) {
        btnEl.className = 'dap-btn stop';
        btnEl.innerHTML = `<svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg> Stop Tracking`;
      }
    } else {
      statusEl.className = 'dap-status';
      if (stxtEl) stxtEl.textContent = 'idle';
      if (btnEl) {
        btnEl.className = 'dap-btn go';
        btnEl.innerHTML = `<svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><polygon points="5,3 19,12 5,21"/></svg> Start Tracking`;
      }
    }
  }

  function refreshAutoToggle() {
    const t = document.getElementById('dap-autotog');
    if (t) t.classList.toggle('on', state.autoUpdate);
  }

  // ─── WIRE EVENTS ──────────────────────────────────────────────────────────
  function wireEvents() {
    document.getElementById('dap-close').addEventListener('click', hidePanel);

    document.getElementById('dap-buy').addEventListener('click', () => {
      state.direction = 'BUY'; refreshAll(); saveState();
      if (state.active && state.price) fillFields(state.price);
    });
    document.getElementById('dap-sell').addEventListener('click', () => {
      state.direction = 'SELL'; refreshAll(); saveState();
      if (state.active && state.price) fillFields(state.price);
    });

    document.getElementById('dap-autotog').addEventListener('click', () => {
      state.autoUpdate = !state.autoUpdate; refreshAutoToggle(); saveState();
    });

    document.getElementById('dap-tcust').addEventListener('change', (e) => {
      const v = parseInt(e.target.value);
      if (v > 0) { state.targetPts = v; refreshAll(); saveState(); if (state.active && state.price) fillFields(state.price); }
    });
    document.getElementById('dap-scust').addEventListener('change', (e) => {
      const v = parseInt(e.target.value);
      if (v > 0) { state.slPts = v; refreshAll(); saveState(); if (state.active && state.price) fillFields(state.price); }
    });

    document.getElementById('dap-actbtn').addEventListener('click', () => {
      state.active ? stopTracking() : startTracking();
    });
  }

  // ─── DRAGGABLE ────────────────────────────────────────────────────────────
  function makeDraggable(panel, handle) {
    let drag = false, ox = 0, oy = 0;
    handle.addEventListener('mousedown', (e) => {
      if (e.target.id === 'dap-close') return;
      drag = true;
      const r = panel.getBoundingClientRect();
      ox = e.clientX - r.left; oy = e.clientY - r.top;
      document.body.style.userSelect = 'none';
      e.preventDefault();
    });
    document.addEventListener('mousemove', (e) => {
      if (!drag) return;
      panel.style.left = Math.max(0, Math.min(window.innerWidth  - panel.offsetWidth,  e.clientX - ox)) + 'px';
      panel.style.top  = Math.max(0, Math.min(window.innerHeight - panel.offsetHeight, e.clientY - oy)) + 'px';
    });
    document.addEventListener('mouseup', () => {
      if (!drag) return; drag = false;
      document.body.style.userSelect = '';
      chrome.storage.local.set({ panelX: parseInt(panel.style.left), panelY: parseInt(panel.style.top) });
    });
  }

  // ─── PRICE ────────────────────────────────────────────────────────────────
  function getLivePrice() {
    for (const sel of ['.stockLtp','[class*="stockLtp"]','.ltp','[class*="ltp"]','.price-value']) {
      const el = document.querySelector(sel);
      if (el) {
        const n = parseFloat(el.innerText.replace(/[₹,\s]/g,''));
        if (!isNaN(n) && n > 0) return n;
      }
    }
    const b = document.querySelector('.stockLtp .bold-text');
    const l = document.querySelector('.stockLtp .light-text');
    if (b && l) { const n = parseFloat((b.innerText + l.innerText).replace(/[^0-9.]/g,'')); if (!isNaN(n)) return n; }
    return null;
  }

  function startPricePoll() {
    if (intervalId) clearInterval(intervalId);
    intervalId = setInterval(() => {
      if (!panelVisible) return;
      const p = getLivePrice();
      if (!p) return;
      state.prevPrice = state.price;
      state.price = p;
      // update price display
      const pv = document.getElementById('dap-pval');
      const pt = document.getElementById('dap-ptime');
      if (pv) {
        pv.textContent = p.toFixed(2);
        const dir = state.prevPrice ? (p > state.prevPrice ? 'up' : p < state.prevPrice ? 'down' : '') : '';
        pv.className = 'dap-pval' + (dir ? ' ' + dir : '');
      }
      if (pt) pt.textContent = 'Updated: ' + new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
      refreshTSL();
      if (state.active && state.autoUpdate) fillFields(p);
    }, 1000);
  }

  // ─── FILL FIELDS ─────────────────────────────────────────────────────────
  function setAngularVal(el, val) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
    setter.call(el, String(val));
    ['input','change','blur'].forEach(ev => el.dispatchEvent(new Event(ev,{bubbles:true})));
  }

  function fillFields(price) {
    const isBuy = state.direction === 'BUY';
    const tv = isBuy ? (price + state.targetPts).toFixed(2)           : Math.max(.05, price - state.targetPts).toFixed(2);
    const sv = isBuy ? Math.max(.05, price - state.slPts).toFixed(2)  : (price + state.slPts).toFixed(2);
    document.querySelectorAll('input[formcontrolname]').forEach(el => {
      const fc = el.getAttribute('formcontrolname');
      if (fc === 'vt_target')   setAngularVal(el, tv);
      if (fc === 'vt_stoploss') setAngularVal(el, sv);
    });
  }

  // ─── TRACKING ─────────────────────────────────────────────────────────────
  function startTracking() {
    state.active = true;
    refreshStatus();
    const p = getLivePrice();
    if (p) { state.price = p; fillFields(p); refreshTSL(); }
    // Auto-stop on order placement
    document.querySelectorAll('.buyBtn,.sellBtn,.placeorderbtn,[class*="instantbtn"]').forEach(btn => {
      btn.addEventListener('click', () => stopTracking(), { once: true });
    });
  }

  function stopTracking() {
    state.active = false;
    refreshStatus();
  }

  // ─── SAVE ─────────────────────────────────────────────────────────────────
  function saveState() {
    chrome.storage.local.set({ targetPts: state.targetPts, slPts: state.slPts, direction: state.direction, autoUpdate: state.autoUpdate });
  }

})();
